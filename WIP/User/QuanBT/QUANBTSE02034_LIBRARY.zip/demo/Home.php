<html> 
<head> 
<script> 


</script> 
<style>
	body{
	background-color :#00FFFF;
	}
	h1{
	color:green;
	text-align:center;
	}
	form{
	text-align:center;
	}
	th{
	color:red;
	background:blue;
	border:1px groove red;
	}
	table{
	width: 100%;
	}
</style>
</head> 
<body> 
<h1>LIBRARY SYSTEM</h1>
<form action="search.php" method=post>
<input type=submit name=search value="Search a book">

</form>
    <form action ="Home.php" method =post>
    
    <?php
	mysql_connect ("localhost","root", "") or
	die ("Couldn't connect to DB");
	mysql_select_db ("librarydb")or
	die ("Couldn't select DB");    
	?>

        <table border=5px groove ="green">
                <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Description</th>
                <th>Author</th>
                <th>Type</th>
                <th>Price</th>
                <th>Created by</th>
                <th>Created date</th>
                <th>Modify date</th>
             
                </tr>
                <?php $result = mysql_query("select * from librarydb") or 
  				 die (mysql_error()); 
 				  while ($row = mysql_fetch_array($result)) 
 				 { ?>
 <tr>
  <td>
   <?php echo $row["ID"]; ?>
  </td>
  <td>
   <img src="<?php echo $row["Image"]?>" width="100" height="100"/>
  </td>
  <td>
   <?php echo $row["Name"]; ?>
  </td>
  <td>
   <?php echo $row["Description"]; ?>
  </td>
  <td>
   <?php echo $row["Author"]; ?>
  </td>
  <td>
   <?php echo $row["Type"]; ?>
  </td>
  <td>
   <?php echo $row["Price"]; ?>
  </td>
  <td>
   <?php echo $row["Created_by"]; ?>
  </td>
  <td>
   <?php echo $row["Created_date"]; ?>
  </td>
  <td>
   <?php echo $row["Modify_date"]; ?>
  </td>
   <?php 
    } 
    mysql_free_result($result); 
   ?>  
         </form>
            </table>
            
            <table>
            <form action="add.php" method="post">
                <input  type="submit" name="AddBook" value="Add a New Book">
            </form>
            <form action="edit.php" method="post">
                <input  type="submit" name="EditBook" value="Edit a Book">
            </form> 
            <form action="delete.php" method="post">
            <input type ="submit" name = "DeleteBook" value = "Delete a book"></form>  
            </table>
                
</body> 
</html> 