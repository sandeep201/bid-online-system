-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2014 at 08:39 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `librarydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `librarydb`
--

CREATE TABLE IF NOT EXISTS `librarydb` (
  `ID` int(44) NOT NULL,
  `Image` varchar(44) DEFAULT NULL,
  `Name` varchar(44) DEFAULT NULL,
  `Description` text,
  `Author` varchar(44) DEFAULT NULL,
  `Type` varchar(44) DEFAULT NULL,
  `Price` int(44) DEFAULT NULL,
  `Created_by` varchar(44) DEFAULT NULL,
  `Created_date` date DEFAULT NULL,
  `Modify_date` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `librarydb`
--

INSERT INTO `librarydb` (`ID`, `Image`, `Name`, `Description`, `Author`, `Type`, `Price`, `Created_by`, `Created_date`, `Modify_date`) VALUES
(1, 'freezing.jpg', 'Freezing', 'One day the earth was invaded by extra-dimensional beings known as The Nova. Using manufactured tissue called Stigmata and branding it into their bodies, a new breed of female warriors was born. these girls possessed the ability to call forth powerful weapons and abilities that far exceeded normal humans. Taking a younger boy as a partner, the two fought as a pair of combatants. These girls are also the only power on earth that have the power to resist the Nova`s freezing effect. Mankind has come to call these girls...', 'KIM Kwang Hyun, IM Dal Young', 'Action, Super Nature, Ecchi', 15, 'QUANBT', '0000-00-00', '2014-05-24'),
(2, 'event2.jpg', 'TNGH', 'i&#7871;u ng&#7841;o giang h&#7891; Trung vãn gi&#7843;n th&#7875;: &#31505;&#20658;&#27743;&#28246;; ph&#7891;n th&#7875;: &#31505;&#20658;&#27743;&#28246;; bính âm: xiào ào ji&#257;ng hú, ti&#7871;ng Anh: The Smiling, Proud Wanderer, ho&#7863;c State of Divinity) là m&#7897;t ti&#7875;u thuy&#7871;t ki&#7871;m hi&#7879;p c&#7911;a Kim Dung, l&#7847;n ð&#7847;u tiên ðý&#7907;c phát hành trên Minh báo t&#7915; ngày 20 tháng 4 nãm 1967 ð&#7871;n 12 tháng 10 nãm 1969.[1] Tiêu ð&#7873; "Ti&#7871;u ng&#7841;o giang h&#7891;" ðý&#7907;c ð&#7863;t theo m&#7897;t b&#7843;n nh&#7841;c c&#7847;m tiêu h&#7907;p t&#7845;u ðóng vai tr&#242; trung tâm c&#7911;a tác ph&#7849;m. Ti&#7871;u ng&#7841;o giang h&#7891; ðý&#7907;c coi là m&#7897;t trong nh&#7919;ng ti&#7875;u thuy&#7871;t ð&#7863;c s&#7855;c nh&#7845;t c&#7911;a tác gi&#7843;.', 'Kim Dung', 'Kiem Hiep', 10, 'QUANBT', '0000-00-00', '2014-05-31'),
(3, 'pokemon.jpg', 'Pokemon', 'Ho&#7841;t h&#236;nh Pokémon (pokemon) vi&#7879;t sub tr&#7885;n b&#7897; hd là tên m&#7897;t b&#7897; anime nhi&#7873;u t&#7853;p, và c&#361;ng là tên c&#7911;a m&#7897;t lo&#7841;i tr&#242; chõi ði&#7879;n t&#7917; và ð&#7891; chõi ðang th&#7883;nh hành &#7903; M&#7929;, Nh&#7853;t và các qu&#7889;c gia khác trên th&#7871; gi&#7899;i. Game Pokémon ðý&#7907;c phát tri&#7875;n b&#7903;i GameFreak và ð&#227; tr&#7903; thành m&#7897;t trong nh&#7919;ng d&#242;ng game d&#7921;a trên ho&#7841;t h&#236;nh n&#7893;i ti&#7871;ng th&#7913; nh&#236; th&#7871; gi&#7899;i, ch&#7881; ð&#7913;ng sau Mario, v&#7889;n c&#361;ng thu&#7897;c Nintendo. S&#7843;n ph&#7849;m Pokémon bao g&#7891;m video, anime, truy&#7879;n tranh, móc khóa, sách &#7843;nh...Nãm 2006 Pokémon t&#7893; ch&#7913;c k&#7881; ni&#7879;m 10 nãm Pokémon ð&#7871;n v&#7899;i công chúng trên toàn th&#7871; gi&#7899;i.', 'Takeshi Shudo', 'Manga', 30, '', '0000-00-00', '0000-00-00'),
(4, 'unbalance.jpg', 'Unbalance x Unbalance', 'Unbalance X Unbalance thuôòc thêÒ lo&#7841;i truy&#7879;n tranh t&#236;nh c&#7843;m nói v&#7873; viêòc làm tôìt là ðem tr&#7843; l&#7841;i ví và m&#7897;t chi&#7871;c ði&#7879;n tho&#7841;i di ð&#7897;ng cho m&#7897;t ph&#7909; n&#7919; tr&#7867; xinh ð&#7865;p (Hae – Young ) trong m&#7897;t c&#7917;a hàng sách chính là Jin – Ho và khi ðý&#7907;c tr&#7843; l&#7841;i vâòt d&#7909;ng cô ð&#227; nh&#7853;n ra m&#236;nh ð&#227; b&#7883; Jin - Ho l&#7845;y m&#7845;t 7000 won. Hae – Young râìt lo l&#7855;ng nhýng r&#7891;i cu&#7889;i cùng cô l&#7841;i quy&#7871;t ð&#7883;nh coi s&#7889; ti&#7873;n ðó là m&#7897;t kho&#7843;n cho vay và trong týõng lai cô s&#7869; ð&#242;i câòu âìy tr&#7843; l&#7841;i. M&#7885;i chuyêòn s&#7869; diêÞn ra nhý thêì nào v&#7899;i h&#7885;? H&#227;y cùng truyen.span.vn theo d&#245;i nh&#7919;ng t&#236;nh ti&#7871;t d&#7877; thýõng c&#7911;a b&#7897; truy&#7879;n tranh Unbalance X Unbalance này nhé!', ' IM Dal Young', 'Ecchi, School', 40, 'QUANBT', '0000-00-00', '2014-05-29'),
(5, 'naruto.jpg', 'Naruto', 'Naruto là m&#7897;t c&#7853;u bé có mõ ý&#7899;c tr&#7903; thành hokage c&#7911;a làng Konoha,ðý&#7907;c Hokage phong &#7845;n trong ngý&#7901;i m&#7897;t trong 9 quái v&#7853;t c&#7911;a th&#7875; gi&#7899;i : C&#7917;u v&#297; H&#7891; ly.V&#236; cho c&#7853;u là m&#7897;t con quái v&#7853;t, ko ai dám chõi v&#7899;i c&#7853;u!& V&#236; mu&#7889;n ðý&#7907;c th&#7915;a nh&#7853;n nên r&#7845;t phá phách.\r\n', 'Kishimoto Masashi ', 'Action Adventure Anime Comedy Drama Fantasy ', 12, 'QUANBT', '2014-05-01', '2014-05-30'),
(6, 'doreamon.jpg', 'Doreamon', 'Ðôrêmon là m&#7897;t b&#7897; truy&#7879;n tranh Nh&#7853;t B&#7843;n c&#7911;a tác gi&#7843; Fujiko Fujio ðý&#7907;c sáng tác t&#7915; nãm 1969 v&#7899;i m&#7909;c ðích ban ð&#7847;u dành cho l&#7913;a tu&#7893;i thi&#7871;u nhi. Tác ph&#7849;m sau ðó ð&#227; ðý&#7907;c chuy&#7875;n th&#7875; thành các t&#7853;p phim ho&#7841;t h&#236;nh ng&#7855;n, dài cùng các th&#7875; lo&#7841;i khác nhý k&#7883;ch, tr&#242; chõi ði&#7879;n t&#7917;. B&#7897; truy&#7879;n k&#7875; v&#7873; m&#7897;t chú mèo máy tên là Ðôrêmon ð&#7871;n t&#7915; th&#7871; k&#7881; 22 ð&#7875; giúp m&#7897;t c&#7853;u bé l&#7899;p 4 h&#7853;u ð&#7853;u tên là Nôbi Nôbita.\r\nK&#7875; t&#7915; khi ra ð&#7901;i ð&#7871;n nay, Ðôrêmon không ch&#7881; ðý&#7907;c coi là nhân v&#7853;t và b&#7897; truy&#7879;n tranh ðý&#7907;c yêu thích hàng ð&#7847;u &#7903; Nh&#7853;t B&#7843;n, nó c&#242;n tr&#7903; thành m&#7897;t bi&#7875;u tý&#7907;ng vãn hóa c&#7911;a ð&#7845;t ný&#7899;c này và ðý&#7907;c tr&#7867; em nhi&#7873;u ný&#7899;c trên th&#7871; gi&#7899;i yêu thích', 'Fujiko.F.Fujio', 'doremon , action , funny , school-life', 11, 'QUANBT', '2014-04-28', '2014-05-06');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
