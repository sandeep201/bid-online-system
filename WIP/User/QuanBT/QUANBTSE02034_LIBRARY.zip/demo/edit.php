


<html>
    <head>
        <style>
            h1,table,form {
                text-align: center;
            }
          
            body{
				background-color :#00FFFF;
			}
        </style>
    </head>
    <body>
    <?php mysql_connect ("localhost","root", "") or
	die ("Couldn't connect to DB");
	mysql_select_db ("librarydb")or
	die ("Couldn't select DB");
	?>
    <form action ="edit.php" method="post">
        <table style ="width: 400px">
            <tr>
                <td>Enter book ID to edit:</td>
                <td>
                    <input type = text name = input>
                </td>
                <td>
                    <input type = submit name = enter value ="Enter">
                </td>
            </tr>
           
            <tr>
            <td>
            
            </td>
            </tr>
        </table>
          <?php error_reporting(E_ERROR);
        $input = $_POST['input'];?>
           <?php 
        
        if(isset($_POST['enter'])){
            
            $result = mysql_query("SELECT * FROM librarydb where ID = '$input'") 
            or die(mysql_error());
            
            while ($row = mysql_fetch_array($result)){
	?>
        <h1>Edit Book</h1>
        <div class="content" >
            <table align="center">
                <tr>
                    <td align="right">Book ID:</td>
                    <td><input type="text" name="ID" value="<?php echo $row["ID"] ?>"><td>
                </tr>
                <tr>
                    <td>image:</td>
                    <td><input type = file name =Image value ="Upload" </td>
                </tr>
                <tr>
                    <td align="right">Book Name:</td>
                    <td><input type="text" name="Name"></td>
                </tr>
                <tr>
                    <td>Author:</td>
                    <td><input type="text" name="Author"></td>
                </tr>
                <tr>
                    <td>Type:</td>
                    <td><input type="text" name="Type"></td>
                </tr>
                <tr>
                    <td>Price:</td>
                    <td><input type="text" name="Price"></td>
                </tr>
                <tr>
                    <td>Description:</td>
                    <td><textarea name="Decription" rows="8"></textarea></td>
                </tr>
                <tr>
                    <td>Created_by:</td>
                    <td><input type= text name=Created_by></td>
                </tr>
                <tr>
                    <td>Created_date:</td>
                    <td><input type = date  name =Created_date></td>
                </tr>
                 <tr>
                    <td>Modify_date:</td>
                    <td><input type=date name="Modify_date"></td>
                </tr>
                <tr>
                    <td>
                        <form action="edit.php" method="post">
                            <input type="submit" name="addnew" value="Submit">
                        </form>
                    </td>
                
                </tr>
            </table>
          </div>
         <?php  }
          }
          ?>
       	  <?php
        if(isset($_POST['addnew'])){
        	$ID=$_POST['ID'];
            $Name = $_POST['Name'];
            $Created_by = $_POST['Created_by'];
            $Crete_date= $_POST['Created_date'];
            $Author = $_POST['Author'];
            $Type = $_POST['Type'];
            $Image = $_POST['Image'];
            $Price = $_POST['Price'];
            $Description = $_POST['Description'];
            $Modify_date=$_POST['Modify_date'];
            $sql = "UPDATE librarydb SET Name = '$Name',Created_by = '$Created_by',Author = '$Author',Type = '$Type',Image = 
           '$Image',Price = '$Price',Description = '$Description' WHERE ID = '$ID'";
            mysql_query($sql) or die();
            echo 'Succesful!!!';
        }
        ?>
        </form>
         <form action="Home.php" method=post>
                            <input type="submit" name="Home" value="Back to home page">
                        </form>
    </body>
</html>