
<head>
<style>
	body{
		background-color:#00FFFF;
	}
	h1{
		color:green;
		text-align:center;
	}
	table{
	width:100%;
	}
	form{
	text-align:center;
	}
</style>
</head>
<body>
<h1>ADD A NEW BOOK</h1>

<form action="add.php" method= post>
<i><b>ID: </b></i>
<input type = text size =40 placeholder="Enter new ID" name =ID><br>	
<i><b>Image:</b></i>
<input type = file name =Image value ="Upload" ><br>
<i><b>Name:</b></i>
<input type = text size =40 placeholder="Enter name" name =Name><br>
<i><b>Description:</b></i>
<textarea name=Description cols=40 rows=4 placeholder="Enter Description of the new book"wrap=virtual></textarea><br>
<i><b>Author: </b></i>
<input type = text size =40 placeholder="Enter author" name =Author><br>
<i><b>Type: </b></i>
<input type = text size =40 placeholder="Enter Type" name =Type><br>	
<i><b>Price: </b></i>
<input type = size =40 placeholder="Enter price" name =Price><br>		
<i><b>Created by: </b></i>
<input type = text placeholder="Enter who create" name =Created_by><br>		
<i><b>Created date: </b></i>
<input type = date  name =Created_date><br>		
<i><b>Modify date: </b></i>
<input type = date  name =Modify_date><br>	
<input type = submit name= add value = "Add">
</form><br>
<form action="Home.php" method= post>
<input type=submit name = Home value = "Back to Home page"> 
</form>

<?php mysql_connect ("localhost","root", "") or
	die ("Couldn't connect to DB");
	mysql_select_db ("librarydb")or
	die ("Couldn't select DB");
	?>
	<?php 
	if (isset($_POST['add'])) 
	{		
	$ID=$_POST['ID'];
	$Image=$_POST['Image'];
	$Name=$_POST['Name'];
	$Description=$_POST['Description'];
	$Author=$_POST['Author'];
	$Type=$_POST['Type'];
	$Price=$_POST['Price'];
	$Created_by=$_POST['Created_by'];
	$Created_date=$_POST['Created_date'];
	$Modify_date=$_POST['Modify_date'];
	$sql="INSERT INTO librarydb(ID,Image,Name,Description,Author,Type,Price,Created_by, Created_date,Modify_date) values
	('$ID','$Image','$Name','$Description','$Author','$Type', '$Price', '$Created_by', '$Created_date','$Modify_date')";
	mysql_query($sql) or die(mysql_error());
	}
	?>
	
</body>
