<html>
    <head>
    <style>
    body{
	background-color :#00FFFF;
	}
	table{
	width:100%;
	}
	h1{
	color:green;
	text-align:center;
	}
    form{
    text-align:center;
    }
    th{
    color:red;
    background:blue;
    }
    </style>
    <body>
   <h1>SEARCH BOOK</h1> 
     <form action ="search.php" method =post name ="search ">
        Search 
                <input type="text" name= find size="40"> by
                <select name="field">
                    <option value="">...</option>
                    <option value="ID">ID</option>
                    <option value="Name">Name</option>
                    <option value="Author">author</option>
                    <option value="Type">Type</option>
                    <option value="Created_by">Created by</option>
                    <option value="Created_date">Created date</option>
                    <option value="Modify_date">Modify date</option>
                </select>
        
                
    <input type =submit value =" Search" name="search">
  </form>
  <form action ="Home.php" method =post>
        <input type =submit  value=" Back to Home page">
        </form>
<table border= 3px groove ="green">
<tr>
<th>ID</th>
<th>Image</th>
<th>Name</th>
<th>Description</th>
<th>Authors</th>
<th>Type</th>
<th>Price($)</th>
<th>Created by</th>
<th>Created date</th>
<th>Modify date</th>
</tr>
     <?php
	mysql_connect ("localhost","root", "") or
	die ("Couldn't connect to DB");
	mysql_select_db ("librarydb")or
	die ("Couldn't select DB");    
	?>
	 <?php error_reporting(E_ERROR);
	if (isset($_POST['search']))  {
    $find = $_POST['find'];
    $field = $_POST['field'];
	$find = strtoupper($find);
	$find = strip_tags($find);
	$find = trim ($find);
    $data = mysql_query("SELECT * FROM librarydb WHERE upper($field) LIKE'%$find%'");
					while ($row = mysql_fetch_array($data)) 
					{ ?>
                 	<tr>
        				<td><?php	echo $row["ID"]; ?></td>
                        <td><img src="<?php echo $row["Image"]?>" width="100" height="100"/></td>
                        <td><?php	echo $row["Name"]; ?></td>
                        <td><?php	echo $row["Description"]; ?></td>
        				<td><?php	echo $row["Author"]; ?></td>
                        <td><?php	echo $row["Type"]; ?></td>
                        <td><?php	echo $row["Price"]; ?></td>
                        <td><?php	echo $row["Created_by"]; ?></td>
        				<td><?php	echo $row["Created_date"]; ?></td>
        				<td><?php	echo $row["Modify_date"]; ?></td>

        				}
        			<?php 
        			} 
        				mysql_free_result($data); 		
	}
                    ?> 	 
    
    
    </body>
    </head>
</html>
