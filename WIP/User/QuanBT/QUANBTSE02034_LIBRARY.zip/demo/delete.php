  <html> 
<head> 
<script> 


</script> 
<style>
	h1{
	color:green;
	text-align:center;
	}
	form{
	text-align:center;
	}
	body{
	background-color :#00FFFF;
	}
</style>
</head> 
<body> 
  
    <?php
	mysql_connect ("localhost","root", "") or
	die ("Couldn't connect to DB");
	mysql_select_db ("librarydb")or
	die ("Couldn't select DB");    
	?>
<h1>DELETE BOOK</h1>


        <form action="delete.php" method="post"> 
        Enter book ID to delete: 
        <input type = "text" name = "ID">
        <input type= submit value = "Delete" name = delete>
        </form>
        <?php
        if (isset($_POST['delete'])){
            $ID = $_POST['ID'];
            mysql_query("DELETE FROM librarydb WHERE ID = $ID");
          	?>
          SUCCESSFUL!!!!!
          	<?php 
          	
        }
          
          ?>
        
       
      
            <form action = "Home.php" method = "post" >
			<input type ="submit" name= "Home" value="Back to home page"></form>
			    
</body> 
</html> 
  